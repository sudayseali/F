import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN");
const CHANNEL_USERNAME = "@payvorachannel";
const CHANNEL_URL = "https://t.me/payvorachannel";
const FRONTEND_URL = Deno.env.get("FRONTEND_URL") || "https://payvora-tan.vercel.app/";

const headers = { "Content-Type": "application/json" };

async function telegram(method: string, body: Record<string, unknown>) {
  if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN is not configured");
  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok || !result.ok) {
    console.error(`Telegram API ${method} failed:`, result);
    throw new Error(`Telegram API request failed: ${method}`);
  }
  return result.result;
}

function isChannelMember(status: string, isMember?: boolean) {
  return status === "creator" || status === "administrator" || status === "member" ||
    (status === "restricted" && isMember === true);
}

function joinKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "📢 Join Payvora Channel", url: CHANNEL_URL }],
      [{ text: "✅ I've Joined — Verify", callback_data: "verify_channel_membership" }],
    ],
  };
}

function appKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🚀 Open Payvora Mini App", web_app: { url: FRONTEND_URL } }],
      [{ text: "📢 Payvora Channel", url: CHANNEL_URL }],
    ],
  };
}

const welcomeText = `<b>Welcome to Payvora! 🎉</b>

Your gateway to completing tasks, earning rewards, and growing your balance.

<b>What you can do with Payvora</b>
💰 Complete tasks and earn rewards
🎯 Discover offers and campaigns
👥 Invite friends and earn referral commissions
💳 Request withdrawals securely

<b>Before you continue</b>
Join our official Telegram channel to access the Payvora Mini App.

👇 Tap below to join, then return here and verify your membership.`;

async function sendJoinMessage(chatId: number | string) {
  await telegram("sendMessage", {
    chat_id: chatId,
    text: welcomeText,
    parse_mode: "HTML",
    reply_markup: joinKeyboard(),
    disable_web_page_preview: true,
  });
}

serve(async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const webhookSecret = Deno.env.get("TELEGRAM_WEBHOOK_SECRET");
  if (webhookSecret) {
    const incomingSecret = req.headers.get("x-telegram-bot-api-secret-token");
    if (!incomingSecret || incomingSecret !== webhookSecret) {
      return new Response("Unauthorized", { status: 401 });
    }
  }

  try {
    const update = await req.json();

    if (update.message?.text) {
      const text = String(update.message.text).trim();
      if (/^\/start(?:@\w+)?(?:\s|$)/.test(text)) {
        await sendJoinMessage(update.message.chat.id);
      }
    } else if (update.callback_query) {
      const callback = update.callback_query;
      const callbackId = callback.id;
      const data = callback.data;
      const chatId = callback.message?.chat?.id;
      const messageId = callback.message?.message_id;
      const userId = callback.from?.id;

      if (data === "verify_channel_membership") {
        if (!chatId || !messageId || !userId) {
          await telegram("answerCallbackQuery", {
            callback_query_id: callbackId,
            text: "Unable to verify this account. Please send /start again.",
            show_alert: true,
          });
        } else {
          const member = await telegram("getChatMember", {
            chat_id: CHANNEL_USERNAME,
            user_id: userId,
          });
          if (isChannelMember(member.status, member.is_member)) {
            await telegram("answerCallbackQuery", {
              callback_query_id: callbackId,
              text: "Membership verified. Welcome to Payvora!",
            });
            await telegram("editMessageText", {
              chat_id: chatId,
              message_id: messageId,
              text: "<b>Membership verified successfully! ✅</b>\n\nYou're all set. Tap below to open Payvora and start earning rewards.",
              parse_mode: "HTML",
              reply_markup: appKeyboard(),
              disable_web_page_preview: true,
            });
          } else {
            await telegram("answerCallbackQuery", {
              callback_query_id: callbackId,
              text: "We couldn't find your channel membership. Join the channel first, then try again.",
              show_alert: true,
            });
            await telegram("editMessageReplyMarkup", {
              chat_id: chatId,
              message_id: messageId,
              reply_markup: joinKeyboard(),
            });
          }
        }
      } else if (data === "help") {
        await telegram("answerCallbackQuery", { callback_query_id: callbackId });
        await telegram("sendMessage", {
          chat_id: chatId,
          text: "Need help with Payvora? Join our official channel for announcements and support: " + CHANNEL_URL,
          disable_web_page_preview: true,
        });
      }
    }

    return new Response(JSON.stringify({ ok: true }), { headers });
  } catch (error) {
    console.error("telegram-webhook processing error:", error instanceof Error ? error.message : String(error));
    return new Response(JSON.stringify({ ok: false, error: "Webhook processing failed" }), {
      status: 500,
      headers,
    });
  }
});
